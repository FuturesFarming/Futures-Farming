#!/usr/bin/env node
/*
  Futures Farming local server
  Serves index.html and relays Yahoo Finance chart requests so the browser can load live data.
  Zero dependencies. Node 18 or newer.   Usage:  node server.js   then open http://localhost:8080
*/
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT) || 8080;
const HOST = process.env.HOST || '127.0.0.1';
const ROOT = __dirname;
const YAHOO = 'https://query1.finance.yahoo.com';
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css', '.json': 'application/json',
  '.png': 'image/png', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.md': 'text/markdown; charset=utf-8' };

/* small in-memory cache so a refresh loop never hammers Yahoo */
const cache = new Map();
const ttl = p => (/period1=|range=730d|range=60d/.test(p) ? 5 * 60e3 : 10e3);

async function relay(p) {
  if (!/^\/v8\/finance\/(chart|spark)[/?]/.test(p)) { const e = new Error('Only /v8/finance/chart and /v8/finance/spark are allowed'); e.status = 400; throw e; }
  const hit = cache.get(p);
  if (hit && Date.now() - hit.t < ttl(p)) return hit.body;
  const r = await fetch(YAHOO + p, { headers: { 'User-Agent': 'Mozilla/5.0 (Futures Farming)', Accept: 'application/json' } });
  const body = await r.text();
  if (!r.ok) { const e = new Error('Yahoo Finance returned ' + r.status); e.status = r.status; throw e; }
  cache.set(p, { t: Date.now(), body });
  if (cache.size > 300) cache.delete(cache.keys().next().value);
  return body;
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname === '/api/yahoo') {
    try {
      const body = await relay(url.searchParams.get('path') || '');
      res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' });
      res.end(body);
    } catch (e) {
      res.writeHead(e.status >= 400 && e.status < 600 ? e.status : 502, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: e.message }));
    }
    return;
  }
  let file = decodeURIComponent(url.pathname);
  if (file === '/') file = '/index.html';
  const full = path.normalize(path.join(ROOT, file));
  if (!full.startsWith(ROOT)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream' });
    res.end(data);
  });
}).listen(PORT, HOST, () => {
  console.log(`\n  Futures Farming is running at http://localhost:${PORT}\n  Live data is relayed from Yahoo Finance. Press Ctrl+C to stop.\n`);
});
