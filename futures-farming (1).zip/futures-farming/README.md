<p align="center"><img src="assets/logo.png" alt="Futures Farming" width="420"></p>

<h3 align="center">An ICT quant terminal for Nasdaq, S&amp;P 500 and Dow futures</h3>

<p align="center">Backtests, live ICT levels, quant statistics, consistency tracking and a trade journal for NQ, ES and YM, minis and micros. One HTML file, no build step, no dependencies to install.</p>

---

## What it does

Futures Farming turns ICT concepts into rules, tests them on years of real CME bars, and puts the results next to a live chart so you can check your manual read against the data before you take a trade.

| Tab | What you get |
| --- | --- |
| **Dashboard** | 24-hour New York killzone dial, live price, time-of-day odds, liquidity ladder (PDH, PDL, PWH, PWL, Asia, London, midnight open), quant bias with a premium/discount gauge, live status of every model, SMT matrix across NQ, ES and YM, model scorecard |
| **Live chart** | 5m, 15m, 1h, 4h and daily candles in New York time with fair value gaps, killzone and Silver Bullet shading, key levels and every backtest trade marked on the bars |
| **Backtests** | Four mechanical ICT models with adjustable target, exit time, holding period, premium/discount filter, period and sizing. Equity curve, drawdown, year-by-year table, monthly heatmap, R distribution, day-of-week, direction and exit breakdown, paginated trade log, CSV export |
| **Quant lab** | How price really behaves: Asia range swept in London, overnight range taken in NY, midnight open bias, when the high and low of day form, previous day raids and failures, weekly profile, daily FVG tap and fill rates, premium/discount odds, day-of-week stats, average daily range. Plain-language takeaways under each section |
| **Consistency** | Every model on every index at a glance, recent vs long-run performance, rolling 20-trade win rate and expectancy, net R by year, Monte Carlo drawdown ranges and the losing streak you should expect |
| **Confluence** | Seven automatic checks from live data plus six manual chart checks, graded A+ to Pass, with a position size calculator for minis and micros |
| **Journal** | Log trades, compare your results per setup with the backtest, export and import JSON or CSV |
| **Settings** | Data source status, proxy for hosted copies, commissions, slippage, account size, sizing and refresh rate |

Data refreshes automatically (every 60 seconds by default), and every chart, statistic and signal updates with it.

## Quick start

**Live data (recommended).** Needs Node 18 or newer, nothing to install.

```bash
git clone https://github.com/<you>/futures-farming.git
cd futures-farming
node server.js        # or: npm start
```

Open **http://localhost:8080**. The server serves the page and relays Yahoo Finance requests, which browsers block when made directly.

**Demo mode.** Double-click `index.html`. If no live source answers, the app switches to clearly labelled simulated prices so you can explore every feature.

## Hosting on GitHub Pages

1. Push the repo and enable Pages (Settings, Pages, deploy from the `main` branch).
2. Browsers cannot call Yahoo directly, so deploy the free Cloudflare Worker shown in the app's **Settings** tab (Cloudflare dashboard, Workers, Create, paste the code, Deploy).
3. In **Settings**, paste `https://<your-worker>.workers.dev/?url=` into Proxy URL and click **Save and connect**.

## The models

All models use conservative fills: if the stop and target fall inside the same bar, the stop is assumed to hit first. Costs default to $4.50 per mini and $1.50 per micro round turn, plus 1 tick of slippage per side.

| Model | Bars | Rules in short |
| --- | --- | --- |
| **Silver Bullet** | 5m | After the 9:30 to 10:00 range is swept, trade the first fair value gap in the opposite direction between 10:00 and 11:00 NY. Stop beyond the sweep, fixed R target, flat by the exit time |
| **NY AM Liquidity Raid** | 1h | A 9:00, 10:00 or 11:00 candle raids the overnight high or low and closes back inside. Enter at the close, stop beyond the candle, fixed R target |
| **Daily Turtle Soup** | 1D | A day raids the previous high or low and closes back inside. Enter at the next open, stop beyond the raid |
| **Daily FVG Continuation** | 1D | A displacement candle leaves a daily gap. Limit entry at the near edge within 10 days, stop beyond the far edge |

Full rules are listed on the Backtests tab next to the results.

### Snapshot of results

NQ mini, 1 contract, 2R target, after costs, data to September 25, 2026. Numbers change as new bars arrive.

| Model | Trades | Profit factor |
| --- | --- | --- |
| Silver Bullet (60 days) | 11 | 1.61 |
| NY AM Liquidity Raid (2 years) | 346 | 0.93 |
| Daily Turtle Soup (since 2000) | 1,161 | 0.91 |
| Daily FVG Continuation (since 2000) | 604 | 1.48 |

The results are mixed on purpose. The tool reports what the rules actually did, including models with no edge, so you can see which ideas hold up and which need a filter.

## Data

- Yahoo Finance continuous contracts: `NQ=F`, `ES=F`, `YM=F`, `MNQ=F`, `MES=F` and `MYM=F`
- Daily bars since 2000, hourly bars for about 2 years and 5-minute bars for the last 60 days. These are Yahoo's limits, so intraday models have shorter histories
- Quotes may be delayed. Continuous contracts roll quarterly, so small jumps around roll dates are normal
- Micros share the mini's price history, with their own point value ($2 MNQ, $5 MES, $0.50 MYM) and commissions

## Keyboard shortcuts

`1` to `8` switch tabs. `N`, `E` and `Y` pick the index. `M` toggles mini and micro.

## Project layout

```
index.html    the whole app: markup, styles, engine and UI in one file
server.js     zero-dependency local server and Yahoo relay (Node 18+)
package.json  npm start
assets/       logo and social preview for the repository
```

Settings and the journal live in memory while the tab is open. Export the journal as JSON to keep it, and import it to restore both the journal and your settings.

Charts by [TradingView Lightweight Charts](https://github.com/tradingview/lightweight-charts) and [Chart.js](https://www.chartjs.org/).

## Disclaimer

Futures Farming is an analysis and education tool, not financial advice. Backtests use historical bars and cannot capture every intrabar path, fee or slippage you will get live. Past results do not guarantee future results. Futures are leveraged, and you can lose more than your deposit.

## License

MIT
